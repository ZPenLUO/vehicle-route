#include "problem.h"

void problem::setdata(){

}
